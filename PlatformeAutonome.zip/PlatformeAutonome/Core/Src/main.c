/* USER CODE BEGIN Header */
/**
******************************************************************************
* @file           : main.c
* @brief          : Main program body
******************************************************************************
* @attention
*
* Copyright (c) 2022 STMicroelectronics.
* All rights reserved.
*
* This software is licensed under terms that can be found in the LICENSE file
* in the root directory of this software component.
* If no LICENSE file comes with this software, it is provided AS-IS.
*
******************************************************************************
*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

void All_led_off(LED_TypeDef *ledHG, LED_TypeDef *ledHD, LED_TypeDef *ledBG,LED_TypeDef *ledBD){
	LedR_turnOff(ledHD); LedG_turnOff(ledHD); LedB_turnOff(ledHD);
	LedR_turnOff(ledBD); LedG_turnOff(ledBD); LedB_turnOff(ledBD);
	LedR_turnOff(ledHG); LedG_turnOff(ledHG); LedB_turnOff(ledHG);
	LedR_turnOff(ledBG); LedG_turnOff(ledBG); LedB_turnOff(ledBG);
}

void moteur_avance(){
	GPIOC->ODR &=~(1<<6);
	GPIOB->ODR |=(1<<11);
	GPIOA->ODR &=~(1<<0);
	GPIOA->ODR |=(1<<1);
}
void moteur_tourne_droite(){
	GPIOC->ODR |=(1<<6);
	GPIOB->ODR &=~(1<<11);
	GPIOA->ODR &=~(1<<0);
	GPIOA->ODR |=(1<<1);
}
void moteur_tourne_gauche(){
	GPIOC->ODR &=~(1<<6);
	GPIOB->ODR |=(1<<11);
	GPIOA->ODR |=(1<<0);
	GPIOA->ODR &=~(1<<1);
}
void moteur_recule(){
	GPIOC->ODR |=(1<<6);
	GPIOB->ODR &=~(1<<11);
	GPIOA->ODR |=(1<<0);
	GPIOA->ODR &=~(1<<1);
}
void moteur_stop(){
	//Moteur droit
	GPIOC->ODR &=~(1<<6);
	GPIOB->ODR &=~(1<<11);
	//Moteur gauche
	GPIOA->ODR &=~(1<<0);
	GPIOA->ODR &=~(1<<1);
}
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
* @brief  The application entry point.
* @retval int
*/
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */

	LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
	LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);

	/* System interrupt init*/
	/* SysTick_IRQn interrupt configuration */
	NVIC_SetPriority(SysTick_IRQn, 3);

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	/* USER CODE BEGIN 2 */
	int distUSG = 0;
	int distUSD = 0;
	int distIRG = 0;
	int distIRD = 0;

	//Allocation de la mémoire au différents structures des composants
	HCSR04 USG = (HCSR04)malloc(sizeof(struct sHCSR04));
	HCSR04 USD = (HCSR04)malloc(sizeof(struct sHCSR04));
	LED_TypeDef *ledHG = (LED_TypeDef*)malloc(sizeof(LED_TypeDef));
	LED_TypeDef *ledBD = (LED_TypeDef*)malloc(sizeof(LED_TypeDef));
	LED_TypeDef *ledBG = (LED_TypeDef*)malloc(sizeof(LED_TypeDef));
	LED_TypeDef *ledHD = (LED_TypeDef*)malloc(sizeof(LED_TypeDef));
	PWM_pin pinBUZZ;

	//Initialisation des capteurs ultrasons
	USD->portTrig = GPIOC;
	USD->portEcho = GPIOA;
	USD->pinTrig = 7;
	USD->pinEcho = 9;
	initUS(USD);

	USG->portTrig = GPIOC;
	USG->portEcho = GPIOC;
	USG->pinTrig = 10;
	USG->pinEcho = 12;
	initUS(USG);

	//Initialisation des leds
	ledBG->gpioPortR=GPIOB;
	ledBG->pinR=9;
	ledBG->gpioPortG=GPIOB;
	ledBG->pinG=8;
	ledBG->gpioPortB=GPIOC;
	ledBG->pinB=8;
	Led_init(ledBG);

	ledBD->gpioPortR=GPIOA;
	ledBD->pinR=10;
	ledBD->gpioPortG=GPIOB;
	ledBD->pinG=5;
	ledBD->gpioPortB=GPIOB;
	ledBD->pinB=3;
	Led_init(ledBD);

	ledHG->gpioPortR=GPIOB;
	ledHG->pinR=6;
	ledHG->gpioPortG=GPIOA;
	ledHG->pinG=6;
	ledHG->gpioPortB=GPIOB;
	ledHG->pinB=12;
	Led_init(ledHG);

	ledHD->gpioPortR=GPIOB;
	ledHD->pinR=4;
	ledHD->gpioPortG=GPIOA;
	ledHD->pinG=8;
	ledHD->gpioPortB=GPIOB;
	ledHD->pinB=10;
	Led_init(ledHD);

	//Initialisation du buzzer
	pinBUZZ = buzzer_init(GPIOA, 7, 16000000);
	set_freq(pinBUZZ, 500);

	//Initialisation des capteurs infrarouges
	int IRG_chan = 10, IRD_chan = 11;
	ADC_init(ADC1, 12, IRG_chan);

	/* USER CODE END 2 */
	/* Infinite loop */

	/* USER CODE BEGIN WHILE */
	//initalisation des moteurs
	RCC->IOPENR |= RCC_IOPENR_GPIOAEN;
	RCC->IOPENR |= RCC_IOPENR_GPIOBEN;
	RCC->IOPENR |= RCC_IOPENR_GPIOCEN;
	GPIOC->MODER &=~ (0b11<<6*2);
	GPIOC->MODER |= (0b01<<6*2);
	GPIOB->MODER &=~ (0b11<<11*2);
	GPIOB->MODER |= (0b01<<11*2);
	GPIOA->MODER &=~ (0b011<<0*2);
	GPIOA->MODER |= (0b01<<0*2);
	GPIOA->MODER &=~ (0b11<<1*2);
	GPIOA->MODER |= (0b01<<1*2);

	moteur_stop();
	buzz_off(pinBUZZ);
	All_led_off(ledHD, ledHG, ledBD, ledBG);

	while (1)
	{
	/* USER CODE END WHILE */
		//LL_mDelay(time_buzz);
		buzz_off(pinBUZZ);
		moteur_avance();
		//MOTEUR AVANCE
//CAPTEUR US GAUCHE -------------------------------------------------------
		distUSG = captUS(USG);
		if(distUSG < 20){
			set_freq(pinBUZZ, 3000);
			buzz_on(pinBUZZ);
			LedG_turnOff(ledHG);
			LedB_turnOff(ledHG);
			LedR_turnOn(ledHG);
			moteur_tourne_droite();
			//MOTEUR TOURNE A DROITE
		}
		else if(distUSG < 50){
			LedG_turnOff(ledHG);
			LedR_turnOff(ledHG);
			LedB_turnOn(ledHG);
			//MOTEUR TOURNE un peu A DROITE
		}
		else if(distUSG < 100){//distUSG compris entre 50 et 100
			LedR_turnOff(ledHG);
			LedB_turnOff(ledHG);
			LedG_turnOn(ledHG);
		}
		else {
			LedR_turnOn(ledHG);
			LedG_turnOn(ledHG);
			LedB_turnOn(ledHG);
		}
//FIN CAPTEUR US GAUCHE ---------------------------------------------------
//CAPTEUR US DROIT --------------------------------------------------------
		distUSD = captUS(USD);
		if(distUSD < 20){
			set_freq(pinBUZZ, 3000);
			buzz_on(pinBUZZ);
			LedG_turnOff(ledHD);
			LedB_turnOff(ledHD);
			LedR_turnOn(ledHD);
			moteur_tourne_gauche();
			//MOTEUR TOURNE A GAUCHE
		}
		else if(distUSD < 50){
			LedG_turnOff(ledHD);
			LedR_turnOff(ledHD);
			LedB_turnOn(ledHD);
			//MOTEUR TOURNE un peu A GAUCHE
		}
		else if(distUSD < 100){//distUSD compris entre 50 et 100
			LedR_turnOff(ledHD);
			LedB_turnOff(ledHD);
			LedG_turnOn(ledHD);
		}
		else {
			LedR_turnOn(ledHD);
			LedG_turnOn(ledHD);
			LedB_turnOn(ledHD);
		}
//FIN CAPTEUR US DROIT ----------------------------------------------------
//IR GAUCHE --------------------------------------------------------
		distIRG = captIR(IRD_chan, IRG_chan);
		for(int i=0;i<70;i++){
			distIRG+=captIR(IRD_chan, IRG_chan);
		}
		distIRG = distIRG/70;
		if(distIRG > 11){
			if(distIRG < 15){
				set_freq(pinBUZZ, 1500);
				buzz_on(pinBUZZ);
				LedG_turnOff(ledBG);
				LedB_turnOff(ledBG);
				LedR_turnOn(ledBG);
				moteur_tourne_droite();
				//MOTEUR TOURNE A DROITE
			}
			else if(distIRG < 30){
				LedG_turnOff(ledBG);
				LedR_turnOff(ledBG);
				LedB_turnOn(ledBG);
				moteur_tourne_droite();
				//MOTEUR TOURNE un peu A DROITE
			}
			else if(distIRG < 50){//distUSD compris entre 50 et 100
				LedR_turnOff(ledBG);
				LedB_turnOff(ledBG);
				LedG_turnOn(ledBG);
			}
		}
		else {
			LedR_turnOn(ledBG);
			LedG_turnOn(ledBG);
			LedB_turnOn(ledBG);
		}
//FIN CAPTEUR IR GAUCHE ----------------------------------------------------
//CAPTEUR IR DROIT --------------------------------------------------------
		distIRD = captIR(IRG_chan, IRD_chan);
		for(int i=0;i<70;i++){
			distIRD+=captIR(IRG_chan, IRD_chan);
		}
		distIRD = distIRD/70;
		if(distIRD > 11){
			if(distIRD < 15){
				set_freq(pinBUZZ, 1500);
				buzz_on(pinBUZZ);
				LedG_turnOff(ledBD);
				LedB_turnOff(ledBD);
				LedR_turnOn(ledBD);
				LL_mDelay(10000);
				moteur_tourne_gauche();
				//MOTEUR TOURNE A GAUCHE
			}
			else if(distIRD < 30){
				LedG_turnOff(ledBD);
				LedR_turnOff(ledBD);
				LedB_turnOn(ledBD);
				moteur_tourne_gauche();
				//MOTEUR TOURNE un peu A GAUCHE
			}
			else if(distIRD < 50){//distUSD compris entre 50 et 100
				LedR_turnOff(ledBD);
				LedB_turnOff(ledBD);
				LedG_turnOn(ledBD);
			}
		}
		else {
			LedR_turnOn(ledBD);
			LedG_turnOn(ledBD);
			LedB_turnOn(ledBD);
		}
//FIN CAPTEUR IR DROIT ----------------------------------------------------




	/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
* @brief System Clock Configuration
* @retval None
*/
void SystemClock_Config(void)
{
LL_FLASH_SetLatency(LL_FLASH_LATENCY_0);
while(LL_FLASH_GetLatency()!= LL_FLASH_LATENCY_0)
{
}
LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE1);
LL_RCC_HSI_Enable();

/* Wait till HSI is ready */
while(LL_RCC_HSI_IsReady() != 1)
{

}
LL_RCC_HSI_SetCalibTrimming(16);
LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_1);
LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_1);
LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_HSI);

/* Wait till System clock is ready */
while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSI)
{

}

LL_Init1msTick(16000);

LL_SetSystemCoreClock(16000000);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
* @brief  This function is executed in case of error occurrence.
* @retval None
*/
void Error_Handler(void)
{
/* USER CODE BEGIN Error_Handler_Debug */
/* User can add his own implementation to report the HAL error return state */
__disable_irq();
while (1)
{
}
/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
* @brief  Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  file: pointer to the source file name
* @param  line: assert_param error line source number
* @retval None
*/
void assert_failed(uint8_t *file, uint32_t line)
{
/* USER CODE BEGIN 6 */
/* User can add his own implementation to report the file name and line number,
 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

